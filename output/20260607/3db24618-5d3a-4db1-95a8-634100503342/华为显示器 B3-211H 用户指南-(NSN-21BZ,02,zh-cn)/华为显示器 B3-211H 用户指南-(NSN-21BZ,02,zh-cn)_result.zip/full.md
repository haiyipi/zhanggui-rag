# 用户指南

# 目录

关于本手册

显示器外观和接口介绍

安装与拆卸显示器

显示器连接至计算机等设备

显示器开关机及 OSD 菜单设置

显示器菜单选项

支持的显示模式

常见问题

安全信息

法律声明

# 关于本手册

使用设备前请仔细阅读本手册。

手册中展示的组件可能未包含在设备内，您需要单独购买；手册中描述的功能可能需要与其他组件配合，才能使用；手册中的图形、界面可能和实际有差异，所有图示仅供参考，请以实际产品为准。

# 显示器外观和接口介绍

![](images/1dd239000e6c557447671709eb35571d1db13938107305a0c6c5997f23547456.jpg)

<details>
<summary>text_image</summary>

Diagram of a computer monitor with labeled parts: front panel, top panel, and base.
</details>

![](images/2abb1d2538c7b3a4f6ff2fd8763940f5a162b24ff5f084dfadd39da0dc4f6876.jpg)

<details>
<summary>text_image</summary>

Diagram of a computer monitor with labeled parts and dashed lines indicating alignment or connection points
</details>

![](images/1b183ba0e7a0bd63ec115d674e4a3daacc3dd993efaf3391905a009c6cba74e0.jpg)

<details>
<summary>flowchart</summary>

```mermaid
graph TD
    A["7"] --> B[" "]
    C["8"] --> D[" "]
    E["9"] --> F[" "]
    G["10"] --> H[" "]
```
</details>

<table><tr><td>序列号</td><td>按键功能</td></tr><tr><td>1</td><td>显示器面板</td></tr><tr><td>2</td><td>立柱</td></tr><tr><td>3</td><td>底座</td></tr><tr><td>4</td><td>电源指示灯·开机状态白色常亮。·关机状态熄灭。·睡眠状态白色闪烁。</td></tr><tr><td>5</td><td>电源键开启关闭显示器。</td></tr><tr><td>6</td><td>功能键调节显示器设置。详细内容,请查看《显示器开关机及 OSD 菜单设置》章节。</td></tr><tr><td>7</td><td>HDMI 接口连接 HDMI 输入设备,如计算机。</td></tr><tr><td>8</td><td>VGA 接口连接 VGA 输入设备,如计算机。</td></tr><tr><td>9</td><td>耳机接口连接耳机。</td></tr><tr><td>10</td><td>电源接口连接电源适配器,给显示器供电。</td></tr></table>

# 安装与拆卸显示器

# 安装

1   
![](images/383d9cfa52f0ead28cb7606ae9d7094f25b5977208238b227389156a447caccd.jpg)

<details>
<summary>natural_image</summary>

Isometric line drawing of a device housing with internal components and an arrow indicating direction (no text or symbols)
</details>

2   
![](images/476e94aa3de74e7c5ca212abb7885fa71642e2573cbcff84701856b5892075c2.jpg)

<details>
<summary>natural_image</summary>

Technical line drawing of a device housing with internal compartments and mounting holes (no text or symbols)
</details>

3   
![](images/33820c6836dbad13bd27666d3755b38589d96d939fbc9d4f7ce21d1fe3aab27b.jpg)

<details>
<summary>natural_image</summary>

Technical line drawing of a device assembly showing internal components and a separate mounting bracket (no text or symbols)
</details>

4   
![](images/31d6b74df3cf1c0c2475a7e7a677c94ac498509198b6544a755f0f05f22b1825.jpg)

<details>
<summary>natural_image</summary>

Line drawing of a flat-screen computer monitor with no text or symbols on the screen
</details>

1 缓冲泡沫箭头朝上水平放置纸箱，打开纸箱包装，将整机和缓冲泡沫一起取出。  
2 从缓冲泡沫中取出立柱和底座。  
3 将立柱上端插入显示器背部的卡槽，听到咔哒声表示已安装好。然后将底座安装到立柱下端，听到咔哒声表示已安装好。  
4 将组装好的显示器用双手托起，立在平整的桌面上，可根据需要调整俯仰角度。

# 拆卸

![](images/78c42d411f812310ee5f6d6c4d16134049a8c20ef114fa6ee6c679f0fff3d856.jpg)

<details>
<summary>text_image</summary>

Technical diagram showing assembly steps of a device with labeled components and hand gestures
</details>

拆卸立柱：一只手按住显示器背部的快拆按钮，同时另外一只手向下拔出立柱，即可拆卸立柱。

拆卸底座：一只手向内拨动底部的快拆拨片，同时另外一只手握住立柱向外顶出底座，即可拆卸底座。

# 显示器连接至计算机等设备

![](images/885fd1d2e688a2805bf449000e7ead38b59186ef7bf6671764c2940417d54b43.jpg)

<details>
<summary>natural_image</summary>

Line drawing of a desktop computer setup with monitor, tower, and power outlet (no text or symbols)
</details>

1 将 HDMI 线缆或 VGA 线缆一端接入显示器的 HDMI 接口或 VGA 接口，另一端接入计算机的 HDMI 接口或 VGA 接口。  
2 将显示器和计算机的电源线等其他线缆连接好后开机，显示器屏幕上显示计算机的屏幕画面，代表连线成功。

# 显示器开关机及 OSD 菜单设置

![](images/2c8b28901219c18da52c54fb8982db1ed1e45b280751052ffba5b6563aae4bf9.jpg)

<details>
<summary>text_image</summary>

Diagram of a computer monitor with five labeled ports and a control panel, showing connections to the screen.
</details>

# 开启与关闭显示器：

\- 开机：短按电源键（按键 5），显示器屏幕显示品牌 Logo 后，指示灯点亮，显示器开启。

显示器工作时，指示灯点亮；显示器无信号输入时，进入待机状态，若菜单中 LED 电源按钮设置为“待机模式时开”，待机状态下指示灯白色闪烁。

· 关机：长按电源键（按键 5）2 秒以上，指示灯熄灭，显示器关机。

# 设置显示器菜单：

1 显示器开机后，短按任意功能键，即可打开显示器设置菜单。  
2 在设置菜单界面，根据界面提示按 1\~5 键，调节显示器的设置。

<table><tr><td rowspan="2">物理按键</td><td colspan="2">快捷菜单</td><td colspan="2">主菜单</td></tr><tr><td>图示</td><td>说明</td><td>图示</td><td>说明</td></tr><tr><td>按键1</td><td><img src="images/3d9666b0e50c84df97bc80f555f945c0436158b091a78fffe01cec7e1bc70663.jpg"/></td><td>退出快捷菜单</td><td><img src="images/a2a85d5892162efba4c74d0aa1d2d413c77fee226b67598701e7758eef158b59.jpg"/></td><td>左移</td></tr><tr><td>按键2</td><td><img src="images/6d1fccb61ddbd4cfa7a38597d23d1dedd345f7d8bac7d7f1bb4f1302daff552d.jpg"/></td><td>快捷键功能快速进入亮度设置菜单界面</td><td><img src="images/dc83ed6ea3244d8101cf413e1d3047e08e29add3eaaaebc0285755b011324f11.jpg"/></td><td>上移</td></tr><tr><td>按键3</td><td></td><td>快捷键功能快速进入情景模式设置菜单界面</td><td><img src="images/19dba552c03b8cdbbcafb9081b96fa2c8369026fcd3bf1545ee38b8b2e244299.jpg"/></td><td>下移</td></tr><tr><td>按键4</td><td></td><td>进入主菜单</td><td><img src="images/14f1cc2b6a14c4ba38060a9a1fe18987c4234e5a1c506f71d5e4084815f1e984.jpg"/></td><td>右移</td></tr><tr><td>按键5</td><td><img src="images/b72e07cb10a8cdbce65c05a7c3b37ec5635d038e352e146bf75c5792c1deb45f.jpg"/></td><td>关机</td><td><img src="images/f82e8c79350ea40a23ad45e8cf6615b7b92997c0c7df2f2556db76a611b88d27.jpg"/></td><td>确认</td></tr></table>

# 显示器菜单选项

i 不同型号、不同版本的显示器、菜单选项存在差异，请以实际为准。

<table><tr><td>一级菜单</td><td>二级菜单</td><td>描述</td></tr><tr><td rowspan="6"><img src="images/cc4c5778e93ccbacbf9d8a7e21fa7d402691f069b9f2f5d41b1f62f37aa8548e.jpg"/>情景模式</td><td>P3色彩</td><td>浏览P3广色域图片或喜好鲜艳色彩的人士,建议选择P3色彩。</td></tr><tr><td>sRGB色彩</td><td>浏览计算机中的图片时,建议选择sRGB色彩。</td></tr><tr><td>HDR色彩</td><td>调色模拟HDR视频色彩效果,建议观赏影视场景使用。</td></tr><tr><td>游戏</td><td>游戏效果增强,建议游戏场景使用。</td></tr><tr><td>电子书</td><td>模拟纸质书籍效果,建议阅读场景使用。</td></tr><tr><td>用户</td><td>用户自定义显示效果。</td></tr><tr><td rowspan="7"><img src="images/246004f2ad0144187c36c0e73cf635d7c5727f8aa487e10f41c3a22618a223da.jpg"/>显示</td><td>亮度</td><td>设置范围为0-100。</td></tr><tr><td>对比度</td><td>设置范围为0-100。i 此功能仅在用户/sRGB色彩/P3色彩模式下且关闭护眼模式,才可使用。</td></tr><tr><td>锐利度</td><td>设置范围为0-100。</td></tr><tr><td>六色</td><td>可单独设置红色、绿色、蓝色、青色、品红色、黄色的色调与饱和度,设置范围为0-100。i 此功能仅在用户模式,才可使用。</td></tr><tr><td>护眼</td><td>可开启或关闭护眼模式。i 长期阅读时,建议开启护眼模式,预防用眼疲劳,使眼睛更加舒服。开启护眼模式后,屏幕显示偏黄为正常现象。此功能仅在用户/sRGB色彩/P3色彩模式下才可使用,其余的情景模式下护眼模式默认为关。</td></tr><tr><td>色温</td><td>可设置为冷色、中性色、标准色、暖色模式的一种。或者在用户自定义选项中,对红、绿、蓝颜色分别设置,设置数值为0-100。i 此功能仅在用户/sRGB色彩/P3色彩模式下且关闭护眼模式,才可使用。</td></tr><tr><td>缩放</td><td>可选择满屏或等比缩放。</td></tr><tr><td></td><td>VGA 设置</td><td>可设置 VGA 信号的水平位置、垂直位置、时钟、相位,设置数值为 0-100。或者可使用自动调整功能,自动设置 VGA 信号的水平位置、垂直位置、时钟、相位数值。i 此功能仅在连接 VGA 信号时,才可使用。</td></tr><tr><td rowspan="2"><img src="images/eeafec094b81f81634718ea68e3c02629dcd963843b6ee13503bfbcbdf140f45.jpg"/>输入源</td><td>HDMI</td><td rowspan="2">连接其他设备时,根据连接线缆,选择对应的输入源。</td></tr><tr><td>VGA</td></tr><tr><td rowspan="3"><img src="images/5788feafa41fc89813e49e3c5c36f15e1cc9351820530369d2f4e381fbae37bc.jpg"/>游戏辅助</td><td>刷新率</td><td>在游戏场景中,可以在此菜单中进行一些辅助设置。开启后,可选择在屏幕左上角或右上角显示刷新率。</td></tr><tr><td>游戏准星</td><td>开启后,在屏幕上显示准星。并可将准星颜色设置为红色或绿色,也可对准星位置重置。</td></tr><tr><td>响应时间</td><td>可开启或关闭响应时间。开启时,可选择标准、快、极快等响应时间。</td></tr><tr><td rowspan="2"><img src="images/d2c6c3cd6a625f73dad63d3c3b1eff93fda57224964a171effb61ee24a7bdfe5.jpg"/>快捷键</td><td>上</td><td>OSD 快捷菜单上方的设置选项,默认为亮度,可设置为情景模式、响应时间、输入源、对比度等选项。</td></tr><tr><td>下</td><td>OSD 快捷菜单下方的设置选项,默认为情景模式,可设置为亮度、响应时间、输入源、对比度等选项。</td></tr><tr><td rowspan="9"><img src="images/33a55d9115c39adc752578ca6483250d2f1404e6e7d7f59c99ad8c113060cdf2.jpg"/>设置</td><td>音量</td><td>可设置音量大小设置数值为 0-100。i 此功能仅在连接 HDMI 信号时,才可使用。</td></tr><tr><td>语言</td><td>可设置为简体中文、英语。</td></tr><tr><td rowspan="2">菜单显示设置</td><td>菜单透明度:可设置菜单的显示透明度,设置数值为 1-8,数字越大透明度越高。</td></tr><tr><td>菜单显示时间:可将菜单显示时间设置为 10-100 秒。</td></tr><tr><td rowspan="2">LED 电源按钮</td><td>待机模式时开:待机状态下,显示器的指示灯白色闪烁。</td></tr><tr><td>待机模式时关:待机状态下,显示器的指示灯熄灭。</td></tr><tr><td>信息</td><td>可查看显示器的 SN 号、固件版本号、情景模式、分辨率、刷新率、输入源等信息。</td></tr><tr><td>ECO Mode</td><td>选择开启或关闭节能模式。i 此功能默认关闭,打开后会减少能耗。开启节能模式后,亮度等选项将无法设置。</td></tr><tr><td>恢复出厂设置</td><td>选择是否将显示器菜单恢复出厂设置。</td></tr></table>

# 支持的显示模式

最大分辨率

1920 x 1080 @ 75 Hz(HDMI)

1920 x 1080 @ 75 Hz(VGA)

推荐分辨率

1920 x 1080 @ 60 Hz(HDMI)

1920 x 1080 @ 60 Hz(VGA)

<table><tr><td>分辨率</td><td>HDMI刷新率</td><td>VGA刷新率</td></tr><tr><td>640 x 480</td><td>60Hz</td><td>60Hz</td></tr><tr><td>640 x 480</td><td>67Hz</td><td>67Hz</td></tr><tr><td>640 x 480</td><td>72Hz</td><td>72Hz</td></tr><tr><td>640 x 480</td><td>75Hz</td><td>75Hz</td></tr><tr><td>720 x 400</td><td>70Hz</td><td>70Hz</td></tr><tr><td>800 x 600</td><td>56Hz</td><td>56Hz</td></tr><tr><td>800 x 600</td><td>60Hz</td><td>60Hz</td></tr><tr><td>800 x 600</td><td>72Hz</td><td>72Hz</td></tr><tr><td>800 x 600</td><td>75Hz</td><td>75Hz</td></tr><tr><td>832 x 624</td><td>75Hz</td><td>75Hz</td></tr><tr><td>1024 x 768</td><td>60Hz</td><td>60Hz</td></tr><tr><td>1024 x 768</td><td>70Hz</td><td>70Hz</td></tr><tr><td>1024 x 768</td><td>75Hz</td><td>75Hz</td></tr><tr><td>1280 x 1024</td><td>60Hz</td><td>60Hz</td></tr><tr><td>1280 x 1024</td><td>75Hz</td><td>75Hz</td></tr><tr><td>1280 x 720</td><td>60Hz</td><td>60Hz</td></tr><tr><td>1280 x 960</td><td>60Hz</td><td>60Hz</td></tr><tr><td>1440 x 900</td><td>60Hz</td><td>60Hz</td></tr><tr><td>1680 x 1050</td><td>60Hz</td><td>60Hz</td></tr><tr><td>1920 x 1080</td><td>60Hz</td><td>60Hz</td></tr><tr><td>1920 x 1080</td><td>75Hz</td><td>75Hz</td></tr></table>

# 常见问题

# 无法开机

- 检查显示器是否处于开机状态。  
- 检查电源线是否正确连接到显示器和电源插座。

# 屏幕上无图像

- 检查所有线缆是否正确连接。  
- 检查显示器和计算机主机是否均处于开机状态。  
- 检查 VGA/HDMI 等信号线是否出现损坏。  
- 如果无上述问题，则重启设备，查看屏幕是否可正常显示图像。

# 屏幕太亮或太暗

\- 打开显示器设置菜单，调节屏幕显示亮度和对比度。

# 屏幕颜色显示异常

- 检查 VGA/HDMI 等信号线是否出现损坏，如插针弯曲。  
- 打开显示器设置菜单，调整色温。

# 安全信息

⚠️【警告】在使用和操作设备前，为确保设备性能最佳，并避免出现危险或非法情况，请查阅并遵循所有的安全信息。

# 电子设备

有明文规定禁止使用无线设备的场所，请勿使用本设备，否则会干扰其它电子设备或导致其它危险。

# 对医疗设备的影响

· 在明文规定禁止使用无线设备的医疗和保健场所，请遵守该场所的规定，并关闭设备。  
- 设备产生的无线电波或含有磁铁可能会影响植入式医疗设备或个人医用设备的正常工作，如起搏器、植入耳蜗、助听器等。若您使用了这些医用设备，请向其制造商咨询使用本设备的限制条件。  
· 在使用本设备时，请与植入的医疗设备（如起搏器、植入耳蜗等）保持至少 15 厘米的距离。

# 易燃易爆区域

- 在加油站（维修站）或靠近易燃物品、化学制剂等任何易燃易爆区域，请勿使用本设备，并遵守所有图形或文字的指示。在燃油或化学制剂存放和运输区或易爆场所内或周围，设备可能引起爆炸或起火。  
- 请勿将设备及其配件与易燃液体、气体或易爆物品放在同一箱子中存放或运输。

# 操作环境

请勿在多灰、潮湿、肮脏或靠近磁场的地方使用设备，以免引起设备内部电路故障。  
- 插拔设备线缆前，请先停止使用设备并断开电源。在插拔线缆时请保持双手干燥。  
- 雷电天气请断开电源，并拔出连接在设备上的所有线缆，以免设备遭雷击损坏。  
- 请勿在雷雨天气使用本设备。雷雨天气可能导致设备故障或电击危险。

\- 请在介于 $0^{\circ} \mathrm{C} \sim 35^{\circ} \mathrm{C}$ 的环境温度中使用本产品，在介于 $-10^{\circ} \mathrm{C} \sim +45^{\circ} \mathrm{C}$ 的环境温度中存储本产品。当环境温度过高或过低时，可能引起产品故障。

\- 请避免设备及其配件雨淋或受潮，否则可能导致火灾或触电危险。

\- 请勿将设备靠近热源或裸露的火源，如电暖器、微波炉、烤箱、热水器、炉火、蜡烛或其他可能产生高温的地方。

\- 设备在运行一段时间后，设备温度会升高。如果设备温度过高，请勿长时间接触，否则可能导致低温烫伤，引起皮肤红肿或色素沉淀。

请勿让儿童或宠物吞咬设备或其配件，以免对其造成伤害或导致设备故障或爆炸。

\- 当不断重复同一动作时（例如玩游戏），您的手、臂、腕、肩、颈或其他身体部位可能会偶尔感觉不适。如果您感觉到不适，请停止使用并咨询医师。

\- 请勿在设备上放置任何物体（如蜡烛、盛水容器等），若有异物或液体进入设备，请立刻停止使用并断开电源，拔出连接在设备上的所有线缆，并联系华为客户服务中心。

【稳定性危险】本设备可能翻倒，造成严重人身伤害或死亡。采取诸如以下的简单的预防措施就能避免许多伤害，特别是对儿童的伤害：

- 始终使用设备制造商建议的柜子或支架。  
- 始终使用能安全支撑本设备的家具，始终确保本设备没有伸出该支撑家具的边缘。  
- 请勿将本设备放在不稳定的位置，请勿将本设备放置在高的家具（例如橱柜或书柜）上。  
- 始终规划好连接到本设备上的电线和电缆，这样它们就不会被绊或拉。  
- 请勿将本设备置于可能铺在本设备和支撑家具之间的织物或其他材料上。  
- 始终教育儿童攀爬家具到达本设备或其控制装置的危险。  
· 在本设备或放置本设备的家具顶部，请勿放置可能引诱儿童攀爬的物品，如玩具和遥控器。  
- 如果设备需要保留并更换位置，也应考虑上述注意事项。

# 儿童健康

- 本设备及其配件可能包含一些小零件，请将设备及其配件放置在儿童接触不到的地方。儿童可能在无意之中损坏本设备及其配件，或吞下小零件导致窒息或其他危险。  
· 本设备并非玩具，儿童应在成人监护下使用设备。

# 配件要求

- 使用未经认可或不兼容的电源、充电器或电池，可能引发火灾、爆炸或其他危险。  
- 只能使用设备制造商认可且与此型号设备配套的配件。如果使用其他类型的配件，可能违反本设备的保修条款以及本设备所处国家的相关规定，并可能导致安全事故。如需获取认可的配件，请与华为客户服务中心联系。

# 电源安全

- 电源插头作为断开电源的装置。  
- 电源插座应安装在设备附近并应易于触及。  
- 当不使用本设备时，请断开电源与设备的连接并从电源插座上拔掉电源插头。  
- 若电源插头或电源线已损坏，请勿继续使用，以免发生触电或火灾。  
- 请勿用湿手触碰电源线，或用拉电源线缆的方式拔出电源。  
请勿用湿手触摸设备或电源，以免发生设备短路、故障或触电。

# 维护和保养

- 不建议您自行升级部件或更换模块。如有相关服务需求，请联系华为客户服务中心。  
- 请保持设备及其配件干燥。请勿使用微波炉或吹风机等外部加热设备对其进行干燥处理。  
- 请勿在温度过高或过低区域放置设备及其配件，否则可能导致设备故障、着火或爆炸。  
- 请勿使设备及其配件受到强烈的冲击或震动，以免损坏设备及其配件，导致设备故障。  
- 清洁和维护前，请停止使用本设备，关闭所有应用，并断开与其他设备的所有连接或线缆。  
- 请勿使用烈性化学制品、清洗剂或强洗涤剂清洁设备或其配件。请使用清洁、干燥的软布擦拭设备或其配件。  
- 请勿将磁条卡（例如银行卡、电话卡等）长期接触本设备，否则可能导致磁条卡被磁场损坏。

\- 如果设备碰撞硬物或设备受到外界的强烈撞击造成破碎，切勿触摸或试图移除破碎的部分，请立即停止使用并及时联系华为客户服务中心。

# 环境保护

- 请勿将本设备及其附件作为普通的生活垃圾处理。  
- 请遵守本设备及其附件处理的本地法令，并支持回收行动。

产品中有害物质的名称及含量

<table><tr><td rowspan="2">部件名称</td><td colspan="10">有害物质</td></tr><tr><td>铅(Pb)</td><td>汞(Hg)</td><td>镉(Cd)</td><td>六价铬(Cr(VI))</td><td>多溴联苯(PBB)</td><td>多溴二苯醚(PBDE)</td><td>邻苯二甲酸二(2-乙基)己酯(DEHP)</td><td>邻苯二甲酸丁基苄酯(BBP)</td><td>邻苯二甲酸二正丁酯(DBP)</td><td>邻苯二甲酸二异丁酯(DIBP)</td></tr><tr><td>电路板</td><td>×</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td></tr><tr><td>屏幕</td><td>×</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td></tr><tr><td>电源适配器</td><td>×</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td></tr><tr><td>附件</td><td>×</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td><td>○</td></tr><tr><td colspan="11">本表格依据SJ/T 11364的规定编制。○:表示该有害物质在该部件所有均质材料中的含量均不超出电器电子产品有害物质限制使用国家标准要求。×:表示该有害物质至少在该部件的某一均质材料中含量超出电器电子产品有害物质限制使用国家标准要求,且由于技术性或经济性等因素的局限,法律法规不规定其限量要求或放宽其限量要求的技术应用。因型号不同,产品可能不包括以上部分部件,请以产品实际销售配置为准。</td></tr></table>

![](images/6c8e1217e6ffc430f701286d6c7c055ac095adb7c84d5d8ecbace8dbd3c67fe4.jpg)

本标识内数字表示产品及附件在正常使用状态下的环保使用期限为 10 年。

某些部件也可能有环保使用期限标识，其环保使用期限以标识内数字为准。

# 法律声明

版权所有 © 2025 华为终端有限公司。保留一切权利。

本手册描述的产品中，可能包含华为及其可能存在的许可人享有版权的软件。除非获得相关权利人的许可，否则，任何人不能以任何形式对前述软件进行复制、分发、修改、摘录、反编译、反汇编、解密、反向工程、出租、转让、分许可等侵犯软件版权的行为，但是适用法律禁止此类限制的除外。

# 商标声明

# HDMI™

HIGH-DEFINITION MULTIMEDIA INTERFACE

HDMI、HDMI High-Definition Multimedia Interface 等词汇、HDMI 商业外观及 HDMI 标识均为 HDMI Licensing Administrator, Inc. 的商标或注册商标。

在本手册以及本手册描述的产品中，出现的其他商标、产品名称、服务名称以及公司名称，由其各自的所有人拥有。

# 注意

本手册描述的产品及其附件的某些特性和功能，取决于当地网络的设计和性能，以及您安装的软件。某些特性和功能可能由于当地网络运营商或网络服务供应商不支持，或者由于当地网络的设置，或者您安装的软件不支持而无法实现。因此，本手册中的描述可能与您购买的产品或其附件并非完全一一对应。

华为保留随时修改本手册中任何信息的权利，无需提前通知且不承担任何责任。

# 责任限制

本手册中的内容均“按照现状”提供，除非适用法律要求，华为对本手册中的所有内容不提供任何明示或暗示的保证，包括但不限于适销性或者适用于某一特定目的的保证。

在适用法律允许的范围内，华为在任何情况下，都不对因使用本手册相关内容及本手册描述的产品而产生的任何特殊的、附带的、间接的、继发性的损害进行赔偿，也不对任何利润、数据、商誉或预期节约的损失进行赔偿。

在相关法律允许的范围内，在任何情况下，华为对您因为使用本手册描述的产品而遭受的损失的最大责任（除在涉及人身伤害的情况中根据适用的法律规定的损害赔偿外）以您购买本产品所支付的价款为限。

# 进出口管制

若需将本手册描述的产品（包括但不限于产品中的软件及技术数据等）出口、再出口或者进口，您应遵守适用的进出口管制法律法规。

# 隐私保护

为了解我们如何保护您的个人信息，请访问 https://consumer.huawei.com/privacy-policy 阅读我们的隐私政策。

本指南仅供参考，不构成任何形式的承诺，产品（包括但不限于颜色、大小、屏幕显示等）请以实物为准。如出现本指南与官网描述不一致的情况，请以官网说明为准，恕不另行通知。